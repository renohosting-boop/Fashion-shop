
// Modal promo
var modal = document.getElementById("promoModal");
var span = document.getElementsByClassName("close")[0];

// Tampilkan modal saat halaman dibuka
window.onload = function() {
  modal.style.display = "flex";
}

// Tutup modal
span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
