# Renz Fashionzone 👕

Website e-commerce sederhana untuk penjualan baju, celana, dan sepatu dengan desain modern, minimalis, dan elegan.  
Dibuat menggunakan **HTML, CSS, dan JavaScript** (frontend only).

## ✨ Fitur

- **Login & Registrasi** sederhana (disimpan di localStorage)
- **Halaman utama** dengan promo & kategori produk
- **Tab kategori produk**:  
  - Baju Kaos  
  - Baju Kemeja  
  - Celana Jeans  
  - Celana Panjang  
  - Sepatu Sneakers  
  - Sepatu Formal  
- **Detail produk** (gambar, harga, deskripsi singkat)
- **Keranjang Belanja** (produk tersimpan di localStorage)
- **Checkout** dengan pilihan metode pembayaran (Transfer Bank, Dana, OVO, Gojek)
- **Halaman Tentang Kami & Kontak**
- **Informasi Pengiriman & Pengembalian Produk**
- **Desain responsif** dengan warna putih, abu, dan biru
- Font elegan: [Montserrat](https://fonts.google.com/specimen/Montserrat)

## 📂 Struktur Folder

